const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
require('express-async-errors');

const connectDB = require('./config/db');
const config = require('./config/env');

// Import routes
const transactionRoutes = require('./routes/transactions');
const analyticsRoutes = require('./routes/analytics');

// Import middleware
const errorHandlerMiddleware = require('./middleware/error-handler');
const notFoundMiddleware = require('./middleware/not-found');

const app = express();

// CORS configuration
app.use(cors({
  origin: ['http://localhost:3000', 'http://localhost:3001'],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// Middleware
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

if (process.env.NODE_ENV !== 'production') {
  app.use(morgan('dev'));
}

// Health check
app.get('/health', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'Expense Tracker Service is running',
    timestamp: new Date().toISOString()
  });
});

// Routes
app.use('/api/v1/transactions', transactionRoutes);
app.use('/api/v1/analytics', analyticsRoutes);

// Error handling middleware
app.use(notFoundMiddleware);
app.use(errorHandlerMiddleware);

const start = async () => {
  try {
    await connectDB();
    console.log('Connected to MongoDB');
    
    const PORT = config.port || 3002;
    app.listen(PORT, () => {
      console.log(`Expense Tracker Service running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

start();
